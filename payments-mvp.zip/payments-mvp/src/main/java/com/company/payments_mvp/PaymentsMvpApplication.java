package com.company.payments_mvp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PaymentsMvpApplication {

	public static void main(String[] args) {
		SpringApplication.run(PaymentsMvpApplication.class, args);
	}

}
