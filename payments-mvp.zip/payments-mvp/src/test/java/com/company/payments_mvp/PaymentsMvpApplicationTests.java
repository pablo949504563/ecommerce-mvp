package com.company.payments_mvp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PaymentsMvpApplicationTests {

	@Test
	void contextLoads() {
	}

}
